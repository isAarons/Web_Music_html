package songMessage;

import java.util.ArrayList;
import java.util.Iterator;

public class testgetSong {
    public static void main(String[] args) {
        getSong get1 = new getSong();
        ArrayList a1 = get1.getSongname();
        ArrayList a2 = get1.getSingername();
        ArrayList a3 = get1.getSongSheetname();
        Iterator i1 = a1.iterator();
        Iterator i2 = a2.iterator();
        Iterator i3 = a3.iterator();
        while (i1.hasNext()){
            String str1 = (String) i1.next();
            System.out.print(" "+str1);
            String str2 = (String)i2.next();
            System.out.print(" "+str2);
            String str3 = (String)i3.next();
            System.out.print(" "+str3);
            System.out.println();
        }

    }
}
